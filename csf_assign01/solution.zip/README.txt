Below is a summary of the work on this assignment:

all work was completed individually. 
